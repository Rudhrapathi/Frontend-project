function Footer() {
    return (
      <footer style={{ padding: '10px', backgroundColor: '#333', color: '#fff', textAlign: 'center' }}>
        <p>&copy; 2025 FoodOrder. All rights reserved.</p>
      </footer>
    );
  }
  
  export default Footer;